package com.tcs.jwt.user;

public enum Role {

	USER, ADMIN
}
